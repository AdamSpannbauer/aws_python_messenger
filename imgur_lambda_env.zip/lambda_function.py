import os
import json
import requests
import pyimgur
import random

######################
# helper functions
######################
##recursively look/return for an item in dict given key
def find_item(obj, key):
    item = None
    if key in obj: return obj[key]
    for k, v in obj.items():
        if isinstance(v,dict):
            item = find_item(v, key)
            if item is not None:
                return item

##recursivley check for items in a dict given key
def keys_exists(obj, keys):
    for key in keys:
        if find_item(obj, key) is None:
            return(False)
    return(True)

##send txt via messenger to id
def send_message(send_id, msg_txt):
    params  = {"access_token": os.environ['access_token']}
    headers = {"Content-Type": "application/json"}
    data = json.dumps({"recipient": {"id": send_id},
                       "message": {"text": msg_txt}})
                       
    r = requests.post("https://graph.facebook.com/v2.6/me/messages", params=params, headers=headers, data=data)
    
    if r.status_code != 200:
        print(r.status_code)
        print(r.text)

##send attach (pic prolly) via messenger to id
def send_attachment(send_id, attach_url):
    params  = {"access_token": os.environ['access_token']}
    headers = {"Content-Type": "application/json"}
    data = json.dumps({"recipient": {
                        "id": send_id
                        },
                        "message": {
                            "attachment": {
                                "type": "image", 
                                "payload": {
                                    "url": attach_url, "is_reusable": True
                                }
                            }
                        }
    })
    r = requests.post("https://graph.facebook.com/v2.6/me/messages", params=params, headers=headers, data=data)
    if r.status_code != 200:
        print(r.status_code)
        print(r.text)

def get_meme():
    im            = pyimgur.Imgur(os.environ['imgur_client_id'])
    memes_gallery = im.get_memes_gallery(limit=30)
    
    meme_urls = []
    for meme in memes_gallery:
        if hasattr(meme, 'images'):
            for image in meme.images:
                if not image.is_nsfw:
                    meme_urls.append(image.link)
    
    out_url = random.sample(meme_urls, 1)[0]
    return(str(out_url))
#-----------------------------------------------------------

def lambda_handler(event, context):
    #debug
    print("event:" )
    print(event)
    print("context")
    print(context)
    
    #handle webhook challenge
    if keys_exists(event, ["params","querystring","hub.verify_token","hub.challenge"):
        v_token   = str(find_item(event['hub.verify_token']))
        challenge = int(find_item(event['hub.challenge']))
        if (os.environ['verify_token'] == v_token):
            return(challenge)
            
    #handle messaging events
    if keys_exist(event, ['entry']):
        event_entry0 = event['entry'][0]
        if keys_exist(event_entry0, ['messaging']):
            messaging_event = event['entry'][0]['messaging'][0]
            msg_txt   = messaging_event['message']['text']
            sender_id = messaging_event['sender']['id']
            
            first_word = msg_txt.split(" ")[0]
            
            if first_word == "!echo":
                send_message(sender_id, msg_txt)
            else:
                send_attachment(sender_id, get_meme())
    
    return(None)
